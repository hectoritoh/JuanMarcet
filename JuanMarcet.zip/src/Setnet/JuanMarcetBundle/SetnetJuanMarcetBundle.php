<?php

namespace Setnet\JuanMarcetBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SetnetJuanMarcetBundle extends Bundle
{
}
